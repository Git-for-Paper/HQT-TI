package storage;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Hashtable;
import java.util.Vector;

import spatialindex.dirtree.DIRTree;

public class DocumentStoreWeight {

    private Store docstore = null;

    private Hashtable pages = new Hashtable();

    public static void main(String[] args) throws Exception{

        String filename = "E:\\program\\spatial_keyword_query\\src\\yelp.txt";

        DocumentStoreWeight ds = new DocumentStoreWeight(filename);

        LineNumberReader lr = new LineNumberReader(new FileReader(filename));
        ds.load(lr);
    }

    public DocumentStoreWeight(String filename){
        docstore = new Store(filename + ".store");
    }

    public void load(LineNumberReader lr) throws Exception{
        int count = 0;

        int id;
        Vector words;
        long start = System.currentTimeMillis();
        String line = lr.readLine();
        String[] temp, tt;
        while (line != null)
        {
            temp = line.split(",");

            id = Integer.parseInt(temp[0]);
            words = new Vector();
            for(int j = 1; j < temp.length; j++){
                tt = temp[j].split(" ");
                if(tt.length != 2) {
                    WeightEntry de = new WeightEntry(Integer.parseInt(tt[0]), 1.0f);
                    words.add(de);
                }
                else{
                    WeightEntry de = new WeightEntry(Integer.parseInt(tt[0]), Double.parseDouble(tt[1]));
                    words.add(de);
                }
            }

            insertDocument(id, words);

            if ((count % 1000) == 0) System.err.println(count);

            count++;
            line = lr.readLine();
        }

        long end = System.currentTimeMillis();

        docstore.flush();

        System.err.println("Operations: " + count);

        System.err.println("Minutes: " + ((end - start) / 1000.0f) / 60.0f);
    }

    public void insertDocument(int id, Vector words){

        try{
            ByteArrayOutputStream bs = new ByteArrayOutputStream();
            ObjectOutputStream ds = new ObjectOutputStream(bs);

            ds.writeObject(words);

            ds.flush();

            docstore.write(id, bs.toByteArray());
        }
        catch(Exception e){
            e.printStackTrace();
        }

    }

    public Vector read(int id, boolean flag){

        Vector words = null;
        id = id % 1575149;
        //System.out.println(id);
        try{
            byte[] data = docstore.read(id, pages);
            if(data == null)
                return null;
            ObjectInputStream ds = new ObjectInputStream(new ByteArrayInputStream(data));
            if(flag)
                words = (Vector)ds.readObject();

                ////////////////////////////
            else{
                words = new Vector();
                Vector v = (Vector)ds.readObject();
                //System.out.println(v);
                for(int i = 0; i < v.size(); i++){
                    WeightEntry de = (WeightEntry)v.get(i);
                    //System.out.println(de.word);
                    if(de.word <= DIRTree.doclen)
                        words.add(de.word);
                }
                //System.out.println(words);
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return words;
    }

    public int getIO(){
        return pages.size();
    }

    public void resetIO(){
        pages.clear();
    }
}

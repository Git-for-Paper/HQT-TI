package storage;

import java.io.Serializable;

import spatialindex.spatialindex.Region;

public class WeightEntryTermMBR implements Serializable{

    public int word;
    public double weight;
    public Region mbr;

    public WeightEntryTermMBR(int id, double w, Region m){
        word = id;
        weight = w;
        mbr = new Region(m);
    }

}

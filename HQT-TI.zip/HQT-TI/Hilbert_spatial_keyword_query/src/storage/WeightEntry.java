package storage;

import java.io.Serializable;

public class WeightEntry implements Serializable{

    public int word;
    public double weight;


    public WeightEntry(int id, double w){
        word = id;
        weight = w;
    }

    public int getWord() {
        return word;
    }

    public void setWord(int word) {
        this.word = word;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }
}

package storage;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Hashtable;
import java.util.Vector;

public class DocumentStore {

    private Store docstore = null;

    private Hashtable pages = new Hashtable();

    public static void main(String[] args){

        try{

//            if (args.length != 1)
//            {
//                System.err.println("Usage: DocumentStore input_file .");
//                System.exit(-1);
//            }

            DocumentStore ds = new DocumentStore("D:\\project\\test\\Hilbert_spatial_keyword_query\\set\\ds2\\bms.txt");

            //load hotel and usgeo datasets
            /////////////////////////////////////////////////////////////////////////
            LineNumberReader lr = new LineNumberReader(new FileReader("D:\\project\\test\\Hilbert_spatial_keyword_query\\set\\ds2\\bms.txt"));
            ds.load(lr);
            /////////////////////////////////////////////////////////////////////////


        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    public DocumentStore(String filename){
        docstore = new Store(filename+".store");
    }

    public void load(LineNumberReader lr){

        try
        {
            int count = 0;

            int id;
            Vector words;
            long start = System.currentTimeMillis();
            String line = lr.readLine();
            String[] temp;
            while (line != null)
            {
                temp = line.split(",");

                id = Integer.parseInt(temp[0]);
                words = new Vector();
                for(int j = 1; j < temp.length; j++){
                    words.add(Integer.parseInt(temp[j]));
                }

                insertDocument(id, words);

                if ((count % 1000) == 0) System.err.println(count);

                count++;
                line = lr.readLine();
            }

            long end = System.currentTimeMillis();

            docstore.flush();

            System.err.println("Operations: " + count);

            System.err.println("Minutes: " + ((end - start) / 1000.0f) / 60.0f);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

    }



    public void insertDocument(int id, Vector words){

        try{
            ByteArrayOutputStream bs = new ByteArrayOutputStream();
            ObjectOutputStream ds = new ObjectOutputStream(bs);

            ds.writeObject(words);
            //System.out.println(words.get(0));

            ds.flush();
            docstore.write(id, bs.toByteArray());
        }
        catch(Exception e){
            e.printStackTrace();
        }

    }

    public Vector read(int id){

        Vector words = null;

        try{
            byte[] data = docstore.read(id, pages);
            if(data == null)
                return null;
            ObjectInputStream ds = new ObjectInputStream(new ByteArrayInputStream(data));
            words = (Vector)ds.readObject();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return words;
    }

    public int getIO(){
        return pages.size();
    }

    public void resetIO(){
        pages.clear();
    }

    public void flush() throws IllegalStateException
    {
        try
        {

            docstore.flush();
        }
        catch (Exception e)
        {
            System.err.println(e);
            throw new IllegalStateException("flush failed with Exception");
        }
    }
}

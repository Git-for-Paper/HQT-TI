package storage;

import java.io.Serializable;

public class posEntry implements Serializable{

    long pos;
    int len;

    public posEntry(long pos, int len){
        this.pos = pos;
        this.len = len;
    }

    public long getPos() {
        return pos;
    }

    public void setPos(long pos) {
        this.pos = pos;
    }

    public int getLen() {
        return len;
    }

    public void setLen(int len) {
        this.len = len;
    }
}

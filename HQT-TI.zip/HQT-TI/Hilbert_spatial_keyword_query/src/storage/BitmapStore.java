package storage;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.BitSet;
import java.util.Hashtable;
import java.util.Vector;

public class BitmapStore {
    private Hashtable pages = null;
    private Store store = null;
    public int bigword = -1;
    private int count = 0;

    public BitmapStore(String filename, int big){
        store = new Store(filename + ".bitmap." + big);
        bigword = big;
        pages = new Hashtable();
    }

    public void addDocument(BitSet bitmap, Vector document){
        try{
            for(int i = 0; i < document.size(); i++){
                int word = (Integer)document.get(i);
                int pos = word % bigword;
                bitmap.set(pos);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void addDocument(BitSet bitmap, BitSet document){
        try{
            bitmap.or(document);
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void store(int id, BitSet bitmap){
        try{
            ByteArrayOutputStream bs = new ByteArrayOutputStream();
            ObjectOutputStream ds = new ObjectOutputStream(bs);

            ds.writeObject(bitmap);

            ds.flush();

            this.store.write(id, bs.toByteArray());

            if(count % 1000 == 0)
                store.flushbtree();

            count++;

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void store(int id, Vector document){
        try{
            BitSet bitmap = new BitSet(bigword);

            for(int j = 0; j < document.size(); j++){
                int word = (Integer)document.get(j);
                int pos = word % bigword;
                bitmap.set(pos);
            }

            ByteArrayOutputStream bs = new ByteArrayOutputStream();
            ObjectOutputStream ds = new ObjectOutputStream(bs);

            ds.writeObject(bitmap);

            ds.flush();

            this.store.write(id, bs.toByteArray());



        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public BitSet read(int id){

        BitSet bitmap = null;

        try{
            byte[] data = store.read(id, pages);

            ObjectInputStream ds = new ObjectInputStream(new ByteArrayInputStream(data));
            bitmap = (BitSet)ds.readObject();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return bitmap;
    }

    public void flush() throws IllegalStateException
    {
        try
        {

            store.flush();
        }
        catch (Exception e)
        {
            System.err.println(e);
            throw new IllegalStateException("flush failed with Exception");
        }
    }

    public void flushbtree() throws IllegalStateException
    {
        try
        {

            store.flushbtree();
        }
        catch (Exception e)
        {
            System.err.println(e);
            throw new IllegalStateException("flush failed with Exception");
        }
    }

    public boolean booleanfilter(int id, Vector qwords, int level){

        boolean flag = true;
        try{
            if(level == 0){
                id = (id+1) *(-1);
            }
            //System.out.println(level);
            BitSet bitmap = read(id);
            for(int i = 0; i < qwords.size(); i++){
                int word = (Integer)qwords.get(i);
                int pos = word % bigword;
                if(!bitmap.get(pos))
                    return false;
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return flag;
    }
    public int getIO(){
        return pages.size();
    }

    public void resetIO(){
        pages.clear();
    }
}

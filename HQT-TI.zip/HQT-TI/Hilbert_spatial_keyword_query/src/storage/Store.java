package storage;

import java.io.RandomAccessFile;
import java.util.Hashtable;
import java.util.Properties;

import jdbm.RecordManager;
import jdbm.RecordManagerFactory;
import jdbm.btree.BTree;
import jdbm.helper.DefaultSerializer;
import jdbm.helper.IntegerComparator;
import jdbm.helper.IntegerSerializer;

public class Store {

    private RandomAccessFile filestore = null;
    private String DATABASE;
    private String BTREE_NAME;
    private RecordManager recman;
    private long          recid;
    private BTree         btree;
    private Properties    props;
    private Hashtable btrees;

    private int count = 0;
    private int page_size = 4096;
    //for index
    public Store(String filename, boolean flag){
        btrees = new Hashtable();
        props = new Properties();
        DATABASE = filename;
        try {
            // open database and setup an object cache
            recman = RecordManagerFactory.createRecordManager( DATABASE, props );

            filestore = new RandomAccessFile(filename, "rw");
        } catch ( Exception except ) {
            except.printStackTrace();
        }

    }

    public void createBTree(int treeid){

        try{
            BTREE_NAME = String.valueOf(treeid);
            recid = recman.getNamedObject( BTREE_NAME );
            if ( recid != 0 ) {
                System.out.println("Existing inverted file BTree" + treeid);
                System.exit(-1);
            } else {

                btree = BTree.createInstance( recman, new IntegerComparator(), new IntegerSerializer(), new DefaultSerializer(), 500);
                recman.setNamedObject( BTREE_NAME, btree.getRecid() );

            }
            btrees.put(treeid, btree);
        } catch ( Exception except ) {
            except.printStackTrace();
        }

    }
    public void loadBTree(int treeid){

        try{
            BTREE_NAME = String.valueOf(treeid);
            recid = recman.getNamedObject( BTREE_NAME );
            if ( recid != 0 ) {
                btree = BTree.load( recman, recid );
            } else {
                System.out.println("Couldn't find inverted file BTree" + treeid);
                System.exit(-1);
            }
        } catch ( Exception except ) {
            except.printStackTrace();
        }

    }

    ////////////////////////////////////////////////////////////////////////////////////
    //for document
    public Store(String filename){

        props = new Properties();
        DATABASE = filename;
        BTREE_NAME = filename;

        try {
            // open database and setup an object cache
            recman = RecordManagerFactory.createRecordManager( DATABASE, props );
            System.out.println(DATABASE);

            // try to reload an existing B+Tree
            recid = recman.getNamedObject( BTREE_NAME );
            //System.out.println(recid);
            if ( recid != 0 ) {
                btree = BTree.load( recman, recid );
                System.out.println( "Reloaded existing BTree with " + btree.size()
                        + " records." );
                filestore = new RandomAccessFile(filename, "r");

            } else {
                // create a new B+Tree data structure and use a StringComparator
                // to order the records based on people's name.
                btree = BTree.createInstance( recman, new IntegerComparator(), new IntegerSerializer(), new DefaultSerializer(), 500);
                recman.setNamedObject( BTREE_NAME, btree.getRecid() );
                //System.out.println(btree.getRecid());
                System.out.println( "Created a new empty BTree" );

                filestore = new RandomAccessFile(filename, "rw");
            }
        } catch ( Exception except ) {
            except.printStackTrace();
        }

    }

    public void flush() throws IllegalStateException
    {
        try
        {
            recman.commit();
            filestore.close();
        }
        catch (Exception e)
        {
            System.err.println(e);
            throw new IllegalStateException("flush failed with Exception");
        }
    }

    public void flushbtree() throws IllegalStateException
    {
        try
        {
            recman.commit();

        }
        catch (Exception e)
        {
            System.err.println(e);
            throw new IllegalStateException("flush failed with Exception");
        }
    }

    public void write(int id, byte[] data){
        try{
            long pos = filestore.getFilePointer();
            posEntry pe = new posEntry(pos, data.length);
            filestore.write(data);
            btree.insert(id, pe, true);

            if(count % 10000 == 0)
                recman.commit();
            count++;
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public byte[] read(int id, Hashtable pages){

        byte[] data = null;

        try{
            Object var = btree.find(id);
            if(var == null){
                System.out.println("Couldn't find data " + id);
                //System.exit(-1);
                return null;
            }
            posEntry pe = (posEntry)var;
            filestore.seek(pe.pos);
            data = new byte[pe.len];
            filestore.read(data);

            long pageid = pe.pos / page_size;
            pages.put(pageid, 1);

        }catch(Exception e){
            e.printStackTrace();
        }

        return data;
    }

    public String getTreeID(){
        return BTREE_NAME;
    }
}

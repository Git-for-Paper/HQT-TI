package rulesfcquad;

public class Block {
	
	public int[] pagefile;
	

}

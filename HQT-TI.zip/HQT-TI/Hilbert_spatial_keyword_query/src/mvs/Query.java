package mvs;

import me.lemire.integercompression.IntWrapper;
import org.mapdb.DB;
import quadtree.BuildSFCQ;
import quadtree.Gt;
import quadtree.RegionQueryProcess;
import spatialindex.spatialindex.Point;
import spatialindex.spatialindex.Region;

import java.util.HashSet;
import java.util.TreeSet;
import java.util.Vector;
import java.util.concurrent.ConcurrentNavigableMap;

public class Query {

    public static int MinOid;
    public static int MaxOid;
    public static int BlockAccess = 0;
    public static int ssum = 0;

    public Vector<String> Keywords;

    public Query(){
        Keywords = new Vector<String>();
    }

    public Vector<Integer> GetFinalResult(Object[] mlist, HashSet[] hs, int minterm){

        //	System.out.println(hs[0]);
        Vector<Integer> Result = new Vector<Integer>();
//		if(Keywords.size() == 1){
//			for(int i=0; i<mlist.length; i++){
//				Result.add((int)mlist[i]);
//			}
//		}
//		else{
        for(int i=0; i<mlist.length; i++){
            int curobj = (int)mlist[i];
            //		System.out.println("curobj: " + curobj);
            for(int j=0; j<=Keywords.size(); j++){
                //System.out.println(Keywords.size());
                if(j == minterm){
                    continue;
                }
                if(j == Keywords.size()){
                    Result.add(curobj);
                    break;
                }
                if(!hs[j].contains(curobj)){
                    break;
                }

            }
        }
//		}
        return Result;
    }

    public int[] uncompress(int[] pagefile){
        int[] recovered = new int[BuildSFCQ.BlockSize];
        IntWrapper recoffset = new IntWrapper(0);
        BuildSFCQ.codec.uncompress(pagefile,new IntWrapper(0),pagefile.length,recovered,recoffset);
        //     if(Arrays.equals(data,recovered))
        //       System.out.println("data is recovered without loss");
        //     else
        //       throw new RuntimeException("bug"); // could use assert
        //     System.out.println();
        return recovered;
    }

    public Vector DAAT(DB db, int MinOid, int MaxOid){

        ConcurrentNavigableMap[] map = new ConcurrentNavigableMap[Keywords.size()];
        int MinSize = 99999999;
        int MinSizeKeywordId = 99999999;
        float intvisit = 0;
        for(int i=0; i<Keywords.size(); i++){
            //System.out.println(Keywords.get(i));
            map[i] = db.getTreeMap(Keywords.get(i));
            if(map[i].size() < MinSize){
                MinSize = map[i].size();
                MinSizeKeywordId = i;
            }
        }

        TreeSet mset = new TreeSet<Integer>();
        HashSet[] set = new HashSet[Keywords.size()];
        TreeSet[] pset = new TreeSet[Keywords.size()];
        for(int i=0; i<Keywords.size(); i++){
            set[i] = new HashSet<Integer>();
            pset[i] = new TreeSet<Integer>();
        }

        //System.out.println(MinSizeKeywordId);
        int inikey=0, endkey=0;
        if(map[MinSizeKeywordId].lowerKey(MinOid) != null){
            inikey = (int) map[MinSizeKeywordId].lowerKey(MinOid);
        }
        else{
            inikey = (int) map[MinSizeKeywordId].firstKey();
        }
        if(map[MinSizeKeywordId].lowerKey(MaxOid) != null){
            endkey = (int) map[MinSizeKeywordId].lowerKey(MaxOid);
        }
        else{
            endkey = (int) map[MinSizeKeywordId].firstKey();
        }
        //System.out.println("inikey " + MinSizeKeywordId + ": " + inikey);
        //System.out.println("endkey " + MinSizeKeywordId + ": " + endkey);

        for(int ikey = inikey; ikey <= endkey; ikey = (int)map[MinSizeKeywordId].higherKey(ikey)){
            //	 int[] buf = (int[]) map[MinSizeKeywordId].get(ikey);
            int[] buf0 = (int[]) map[MinSizeKeywordId].get(ikey);	// uncompress
//			 if(!LRUBuffer.IsHit(Keywords.get(MinSizeKeywordId), ikey))
//				 intvisit += buf0.length;
            int[] buf = uncompress(buf0);
            //System.out.println(buf.length);
            for(int i=0; i<buf.length; i++){
                mset.add(buf[i]);
            }
            if(map[MinSizeKeywordId].higherKey(ikey) == null){
                break;
            }
        }

        Object[] minlist = mset.toArray();

        //	for(int i=0; i<minlist.length; i++)
        //		System.out.println("minlist " + ": " + minlist[i]);

        for(int i=0; i<minlist.length; i++){			// fill the pset of other keywords
            int curobj = (int)minlist[i];
            //System.out.println(curobj);
            for(int j=0; j<Keywords.size(); j++){
                if(j == MinSizeKeywordId){
                    continue;
                }
                if(map[j].lowerKey(curobj) != null){
                    pset[j].add((int) map[j].lowerKey(curobj));
                }
                else{
                    continue;
                }
            }
        }

        for(int i=0; i<Keywords.size(); i++){	// get all the list to memory
            if(i == MinSizeKeywordId){
                continue;
            }
            Object[] plist = pset[i].toArray();
            for(int j=0; j<plist.length; j++){
                ssum++;
                int curpage = (int)plist[j];
                //		int[] buf = (int[]) map[i].get(curpage);
                int[] buf0 = (int[]) map[i].get(curpage);
//				if(!LRUBuffer.IsHit(Keywords.get(i), curpage))
//					 intvisit += buf0.length;
                int[] buf = uncompress(buf0);
                for(int k=0; k<buf.length; k++){
                    set[i].add(buf[k]);
                }
            }
        }
        BlockAccess += (intvisit/BuildSFCQ.BlockSize + 1);
        Vector<Integer> res = GetFinalResult(minlist, set, MinSizeKeywordId);
        return res;

    }

}

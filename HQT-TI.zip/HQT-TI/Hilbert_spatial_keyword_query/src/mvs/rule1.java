package mvs;

import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;


public class rule1 {
    public static HashMap<Set,Integer> mp = new HashMap<>();
    public static int[] tj = new int[1000005];//存储每个关键字出现频率的数组
    public static void generate_rule() throws IOException{
        LineNumberReader reader = new LineNumberReader(new FileReader("D:\\project\\test\\Hilbert_spatial_keyword_query\\set\\ds4\\flickrOutput.txt"));
        // 创建一个 LineNumberReader 对象以从“retailOutput.txt”文件中读取数据
        // 创建一个 LineNumberReader 对象以从“retail.dat”文件中读取数据
        LineNumberReader reader1 = new LineNumberReader(new FileReader("D:\\project\\test\\Hilbert_spatial_keyword_query\\set\\ds4\\flickr.txt"));//文本,不是排序后的
        String line;
        String[] temp;
        int id=1;
        while((line = reader1.readLine())!=null){//逐行读取文本文件
            //将每行文本以逗号分隔，并将结果存储在“temp”数组中
            temp = line.split(",");
            // 遍历“temp”数组的每个元素（除第一个元素之外）
            for (int i=1;i<temp.length;i++){//第一不是关键字
                int k = Integer.parseInt(temp[i]);// 将元素解析为整数
                tj[k]++; // 将关键字的频率计数增加 1，只是统计了关键字出现的频率
            }
        }//用来统计关键字出现的频率
        //第一行：
        //1,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29
        /*
        1在for循环时不被读取
        0
        1
        2
        3.....
        tj[]计算的出现的频率，每出现一次，就把tj[]里面的元素加1，作为频率
        * */


        while ((line = reader.readLine()) != null){//也是逐行读取output元素，output主要要用来存放，相互关联的频繁项集出现的频率
            temp = line.split(",");//temp用来存放频繁项集及其出现的频率
            Vector<Integer> v = new Vector<>();//实例化集合，和hash
            Set<Integer> s1 = new HashSet<>();

            for(int i=0;i<temp.length-1;i++){
                v.add(Integer.parseInt(temp[i]));//？？
                s1.add(Integer.parseInt(temp[i]));
                //39,48,29142，最后那个29142是出现的频率，不需要计算，只需要给其赋值id=1，说明39，48这个频繁项集是出现的最多的
            }
            mp.put(s1,id);//将s1里面的值和id存放到集合里

            id++;//id类似于存放的频繁项的排名
        }//HashMsp<Set，Integer>用来统计那两项出现的频率最高，<(39,48),1>, <(39,41),2>

    }

}

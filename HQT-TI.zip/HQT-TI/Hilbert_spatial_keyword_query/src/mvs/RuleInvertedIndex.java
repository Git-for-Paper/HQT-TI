package mvs;

import org.mapdb.DB;
import org.mapdb.DBMaker;
import quadtree.Gt;
import quadtree.RegionQuery;
import rulesfcquad.BuildSFCQ;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.*;

public class RuleInvertedIndex {

    static DB db = DBMaker.newFileDB(new File("Rule"))
            .closeOnJvmShutdown().
                    make();
    static HashMap<Integer, Gt> ObjectTable = new HashMap<Integer, Gt>();

    public static void main(String[] args) throws Exception{
        String text_file = "E:\\program\\spatial_keyword_query\\src\\kosarak.dat";
        String query_file = "E:\\program\\spatial_keyword_query\\src\\queriesx6.txt";
        BufferedReader brt = new BufferedReader(new InputStreamReader(new FileInputStream(text_file)));
        BufferedReader brq = new BufferedReader(new InputStreamReader(new FileInputStream(query_file)));

        rule1.generate_rule();

        String str;
        String strt;
        String strq;
        int count=0;
        long start = System.currentTimeMillis();
        //	String str;
        int id = -1;
        while((strq = brq.readLine()) != null){
            String[] buf = strq.split(",");
            //	double qr = Double.parseDouble(buf[0]);
            id = Integer.parseInt(buf[0]);
            System.out.println("query "+id);
            Query Rq = new Query();
            Vector<Integer> v = new Vector<>();
            for(int i=1; i<buf.length; i++){
                int word_int = Integer.parseInt(buf[i]);
                v.add(word_int);
                //	Rq.Keywords.add("7444");
                //	Rq.Keywords.add("2218");
            }
            v.sort(new Comparator<Integer>() {
                @Override
                public int compare(Integer o1, Integer o2) {
                    return Integer.compare(rule1.tj[o2], rule1.tj[o1]);
                }
            });
            int[] bj=new int[v.size()];
            for(int i=0;i<v.size();i++) {
                if (bj[i] == 1){
                    continue;
                }
                bj[i] = 1;
                Set<Integer> s = new HashSet<>();
                s.add(v.get(i));
                for (int j = i + 1; j < v.size(); j++) {
                    s.add(v.get(j));
                    if (rule1.mp.containsKey(s) == false) {
                        s.remove(v.get(j));
                    } else {
                        bj[j] = 1;
                    }
                }
                for (int j = 0; j < i; j++) {
                    s.add(v.get(j));
                    if (rule1.mp.containsKey(s) == false) {
                        s.remove(v.get(j));
                    } else {
                        bj[j] = 1;
                    }
                }
                if (rule1.mp.containsKey(s)) {
                    Rq.Keywords.add(Integer.toString(rule1.mp.get(s) + BuildRuleInvertedIndex.difKeuword));
                } else {
                    Rq.Keywords.add(Integer.toString(v.get(i)));
                }
            }
            Vector Re = Rq.DAAT(db, 0, 990000);
            System.out.println(Re.size());

        }
        long end = System.currentTimeMillis();
        System.out.println(Query.ssum/1000);
        System.out.println("runtime: " + (end - start));
        System.out.println("block accessed: " + Query.BlockAccess);
    }

}

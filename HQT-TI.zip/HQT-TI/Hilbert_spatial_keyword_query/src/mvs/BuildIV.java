package mvs;

import me.lemire.integercompression.*;
import org.mapdb.DB;
import org.mapdb.DBMaker;
import quadtree.BuildSFCQ;
import trie.Trie;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Vector;
import java.util.concurrent.ConcurrentNavigableMap;

public class BuildIV {

    public static int TotalKeywords = 41270;
    public static int BlockSize = 64;

    public static IntegratedIntegerCODEC codec =  new
            IntegratedComposition(
            new IntegratedBinaryPacking(),
            new IntegratedVariableByte());

    public static int[] Compress(int[] pagefile){
        int[] data = pagefile;
        //    System.out.println("Compressing "+data.length+" integers in one go");
        // data should be sorted for best
        //results
        //    for(int k = 0; k < data.length; k++)
        //      data[k] = k;
        // Very important: the data is in sorted order!!! If not, you
        // will get very poor compression with IntegratedBinaryPacking,
        // you should use another CODEC.

        // next we compose a CODEC. Most of the processing
        // will be done with binary packing, and leftovers will
        // be processed using variable byte
//        IntegratedIntegerCODEC codec =  new
//           IntegratedComposition(
//                    new IntegratedBinaryPacking(),
//                    new IntegratedVariableByte());
        // output vector should be large enough...
        int [] compressed = new int[data.length];
        // compressed might not be large enough in some cases
        // if you get java.lang.ArrayIndexOutOfBoundsException, try
        // allocating more memory

        /**
         *
         * compressing
         *
         */
        IntWrapper inputoffset = new IntWrapper(0);
        IntWrapper outputoffset = new IntWrapper(0);
        codec.compress(data,inputoffset,data.length,compressed,outputoffset);
        // got it!
        // inputoffset should be at data.length but outputoffset tells
        // us where we are...
        System.out.println("compressed from "+data.length*4/1024f+"KB to "+outputoffset.intValue()*4/1024f+"KB");
        // we can repack the data: (optional)
        compressed = Arrays.copyOf(compressed,outputoffset.intValue());
        //    System.out.println("compressed size after repack "+compressed.length*4/1024+"KB");
        return compressed;
    }

    public static int[] uncompress(int[] pagefile){
        int[] recovered = new int[BuildSFCQ.BlockSize];
        IntWrapper recoffset = new IntWrapper(0);
        BuildSFCQ.codec.uncompress(pagefile,new IntWrapper(0),pagefile.length,recovered,recoffset);
        //     if(Arrays.equals(data,recovered))
        //       System.out.println("data is recovered without loss");
        //     else
        //       throw new RuntimeException("bug"); // could use assert
        //     System.out.println();
        return recovered;
    }

    public static void main(String[] args) throws Exception{
        String text_file = "E:\\program\\spatial_keyword_query\\src\\kosarak.dat";
        BufferedReader brt = new BufferedReader(new InputStreamReader(new FileInputStream(text_file)));
        int[] count = new int[TotalKeywords];
        for(int i=0; i<count.length; i++){
            count[i] = BlockSize + 1;
        }

        int id = 0;
        double x, y;

        long start = System.currentTimeMillis();
        String line;
        String[] temp;

        DB db;
        db = DBMaker.newFileDB(new File("IV"))
                .closeOnJvmShutdown().
                        make();

        //	int TotalKeywords = 68053; 		// set the total number of keywords
        System.out.println(TotalKeywords);
        for(int i=0; i<TotalKeywords; i++){
            //	int[] pagefile = new int[128];
            ConcurrentNavigableMap<Integer,int[]> map = db.getTreeMap(String.valueOf(i));
        }

        String str;
        while ((str = brt.readLine()) != null)
        {
            temp = str.split(",");
            for(int k = 1; k < temp.length; k++){
                String word = temp[k];
                ConcurrentNavigableMap<Integer,int[]> map = db.getTreeMap(word);
                int word_int = Integer.parseInt(word);
                if(count[word_int] >= BlockSize){
                    count[word_int] = 0;
                    int[] pagefile = new int[BlockSize];
                    pagefile[count[word_int]] = id;
                    count[word_int]++;
                    map.put(id, pagefile);
                    //System.out.println(pagefile.length);
                }
                else{
                    int maxkey = map.lastKey();
                    int[] pagefile = map.get(maxkey);
                    //System.out.println(count[word_int]+" "+pagefile.length);
                    pagefile[count[word_int]] = id;
                    count[word_int]++;
                    map.put(maxkey, pagefile);
                }
            }
        }

    }
}

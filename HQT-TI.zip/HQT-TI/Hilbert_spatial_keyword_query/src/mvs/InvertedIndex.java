package mvs;

import org.mapdb.DB;
import org.mapdb.DBMaker;
import quadtree.GetZorder;
import quadtree.Gt;
import quadtree.RegionQuery;
import spatialindex.spatialindex.Region;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Vector;

public class InvertedIndex {

    static DB db = DBMaker.newFileDB(new File("Rule"))
            .closeOnJvmShutdown().
                    make();
    static HashMap<Integer, Gt> ObjectTable = new HashMap<Integer, Gt>();

    public static void main(String[] args) throws Exception{

        String text_file = "E:\\program\\spatial_keyword_query\\src\\kosarak.dat";
        String query_file = "E:\\program\\spatial_keyword_query\\src\\queriesx1.txt";
        BufferedReader brt = new BufferedReader(new InputStreamReader(new FileInputStream(text_file)));
        BufferedReader brq = new BufferedReader(new InputStreamReader(new FileInputStream(query_file)));
        String str;
        String strt;
        String strq;
        int count=0;
        long start = System.currentTimeMillis();
        //	String str;
        int id = -1;
        while((strq = brq.readLine()) != null){
            String[] buf = strq.split(",");
            //	double qr = Double.parseDouble(buf[0]);
            id = Integer.parseInt(buf[0]);
            System.out.println("query "+id);
            Query Rq = new Query();
            for(int i=1; i<buf.length; i++){
                Rq.Keywords.add(buf[i]);
            }

            Vector v = Rq.DAAT(db, 0, 990000);
            System.out.println(v.size());


        }
        long end = System.currentTimeMillis();
        System.out.println(RegionQuery.ssum/1000);
        System.out.println("runtime: " + (end - start));
        System.out.println("block accessed: " + RegionQuery.BlockAccess);
    }

}

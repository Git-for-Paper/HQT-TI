package spatialindex.storagemanager;

public class LRUBuffer extends Buffer{

    LRUCache<Integer, Buffer.Entry> cache;

    public LRUBuffer(IStorageManager sm, int capacity, boolean bWriteThrough)
    {
        super(sm, capacity, bWriteThrough);
        cache = new LRUCache<Integer, Buffer.Entry>(capacity);
    }

    public byte[] loadByteArray(final int id)
    {
        byte[] ret = null;
        Buffer.Entry e = (Buffer.Entry) cache.get(new Integer(id));

        if (e != null)
        {
            m_hits++;
            // System.out.println(1);
            ret = new byte[e.m_data.length];
            System.arraycopy(e.m_data, 0, ret, 0, e.m_data.length);
        }
        else
        {
            ret = m_storageManager.loadByteArray(id);
            e = new Buffer.Entry(ret);
            cache.put(new Integer(id), e);
        }

        return ret;
    }



    void addEntry(int id, Buffer.Entry e)
    {

    }

    void removeEntry()
    {

    }

    public int getIO(){
        return m_storageManager.getIO();
    }

}
